#!/bin/sh
set -e
if command -v update-desktop-database >/dev/null 2>&1; then update-desktop-database /usr/share/applications; fi
if command -v update-mime-database >/dev/null 2>&1; then update-mime-database /usr/share/mime; fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then gtk-update-icon-cache -q -t /usr/share/icons/hicolor || true; fi
exit 0
